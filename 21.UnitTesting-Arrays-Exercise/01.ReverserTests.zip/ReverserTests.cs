﻿using System;

using NUnit.Framework;

namespace TestApp.UnitTests;

public class ReverserTests
{
    [Test]
    public void Test_ReverseStrings_WithEmptyArray_ReturnsEmptyArray()
    {
        // Arrange
        string[] input = Array.Empty<string>();

        // Act
        string[] actual = Reverser.ReverseStrings(input);

        // Assert
        Assert.That(actual, Is.EqualTo(Array.Empty<string>()));
        Assert.That(actual, Is.Empty);
    }

    [Test]
    public void Test_ReverseStrings_WithSingleString_ReturnsReversedString()
    {
        // Arrange
        string[] input = new string[] { "Hello" };
        string[] expected = new[] { "olleH" };

        // Act
        string[] actual = Reverser.ReverseStrings(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
        CollectionAssert.AreEqual(expected, actual);
    }

    [Test]
    public void Test_ReverseStrings_WithMultipleStrings_ReturnsReversedStrings()
    {
        // Arrange 
        string[] input = new string[] { "Hello ", " Wor ld " };
        string[] expected = new string[] { " olleH", " dl roW " };

        // Act
        string[] actual = Reverser.ReverseStrings(input);

        // Assert
        //Assert.That(actual, Is.EqualTo(expected));
        CollectionAssert.AreEqual(expected, actual);
    }

    [Test]
    public void Test_ReverseStrings_WithSpecialCharacters_ReturnsReversedSpecialCharacters()
    {
        // Arrange 
        string[] input = new string[] { "!He!llo !", "% Wor% %ld% %" };
        string[] expected = new string[] { "! oll!eH!", "% %dl% %roW %" };

        // Act
        string[] actual = Reverser.ReverseStrings(input);

        // Assert
        CollectionAssert.AreEqual(expected, actual);
    }
}
