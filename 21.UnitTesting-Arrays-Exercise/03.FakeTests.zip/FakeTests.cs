﻿using System;

using NUnit.Framework;

namespace TestApp.UnitTests;

public class FakeTests
{
    [Test]
    public void Test_RemoveStringNumbers_RemovesDigitsFromCharArray()
    {
        // Arrange
        char[] input = new char[] { 'a', '1' };
        char[] expected = new char[] { 'a' };

        // Act
        char[] actual = Fake.RemoveStringNumbers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_RemoveStringNumbers_NoDigitsInInput_ReturnsSameArray()
    {
        // Arrange
        char[] input = new char[] { 'a' };
        char[] expected = new char[] { 'a' };

        // Act
        char[] actual = Fake.RemoveStringNumbers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_RemoveStringNumbers_EmptyArray_ReturnsEmptyArray()
    {
        // Arrange
        char[] input = Array.Empty<char>();

        // Act
        char[] actual = Fake.RemoveStringNumbers(input);

        // Assert
        Assert.That(actual, Is.Empty);
    }
}
