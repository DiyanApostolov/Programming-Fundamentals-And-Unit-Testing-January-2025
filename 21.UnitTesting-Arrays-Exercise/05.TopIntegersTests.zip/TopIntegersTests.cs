﻿using System;

using NUnit.Framework;

namespace TestApp.UnitTests;

public class TopIntegersTests
{
    [Test]
    public void Test_FindTopIntegers_EmptyArrayParameter_ReturnEmptyString()
    {
        // Arrange
        int[] input = Array.Empty<int>();
        string expected = string.Empty;

        // Act
        TopIntegers classInstance = new TopIntegers();
        string actual = classInstance.FindTopIntegers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_FindTopIntegers_AllElementsAreTopIntegers_ReturnStringWithAllElements()
    {
        // Arrange
        int[] input = new int[] { 6, 4, 2 };
        string expected = "6 4 2";

        // Act
        TopIntegers classInstance = new TopIntegers();
        string actual = classInstance.FindTopIntegers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_FindTopIntegers_OnlyOneElementArray_ReturnStringWithOneInteger()
    {
        // Arrange
        int[] input = new int[] { 6 };
        string expected = "6";

        // Act
        TopIntegers classInstance = new TopIntegers();
        string actual = classInstance.FindTopIntegers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_FindTopIntegers_OnlySomeElementsAreTopIntegers_ReturnStringWithOnlyTopIntegers()
    {
        // Arrange
        int[] input = new int[] { 2, 42, 12, 31, 6, 15 };
        string expected = "42 31 15";

        // Act
        TopIntegers classInstance = new TopIntegers();
        string actual = classInstance.FindTopIntegers(input);

        // Assert
        Assert.That(actual, Is.EqualTo(expected));
    }
}

