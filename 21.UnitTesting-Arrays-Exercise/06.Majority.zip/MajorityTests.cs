﻿using System;

using NUnit.Framework;

namespace TestApp.UnitTests;

public class MajorityTests
{
    [Test]
    public void Test_IsEvenOrOddMajority_EmpryArray_ReturnsZero()
    {
        // Arrange
        int[] input = Array.Empty<int>();
        int expected = 0;

        // Act
        int actual = Majority.IsEvenOrOddMajority(input);

        // Assert
        Assert.That(actual, Is.Zero);
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void Test_IsEvenOrOddMajority_ArrayOnlyWithZeros_ReturnsZero()
    {
        // Arrange
        int[] input = new int[] { 0, 0, 0 };

        // Act
        int actual = Majority.IsEvenOrOddMajority(input);

        // Assert
        Assert.That(actual, Is.Zero);
    }

    [Test]
    public void Test_IsEvenOrOddMajority_EqualOddAndEvenNumbers_ReturnsZero()
    {
        // Arrange
        int[] input = new int[] { 1, 3, 5, 2, 4, 6 };

        // Act
        int actual = Majority.IsEvenOrOddMajority(input);

        // Assert
        Assert.That(actual, Is.Zero);
    }

    [Test]
    public void Test_IsEvenOrOddMajority_EvenMajority_ReturnsPositiveNumber()
    {
        // Arrange
        int[] input = new int[] { 1, 3, 2, 4, 6 };

        // Act
        int actual = Majority.IsEvenOrOddMajority(input);

        // Assert
        Assert.That(actual, Is.Positive);
    }

    [Test]
    public void Test_IsEvenOrOddMajority_OddMajority_ReturnsNegativeNumber()
    {
        // Arrange
        int[] input = new int[] { 1, 3, 5, 4, 6 };

        // Act
        int actual = Majority.IsEvenOrOddMajority(input);

        // Assert
        Assert.That(actual, Is.Negative);
    }
}
